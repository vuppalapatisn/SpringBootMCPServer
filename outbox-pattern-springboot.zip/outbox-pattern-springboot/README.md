# Transactional Outbox Pattern – Spring Boot + PostgreSQL + Kafka

Order Service saves an order **and** an `OrderCreated` event in ONE database transaction.
The event is then published to Kafka by either a **polling publisher** (default) or **Debezium CDC**.
The consumer is **idempotent** (inbox table), because the pipeline is at-least-once.

```
POST /api/orders
   │  one DB transaction
   ▼
 orders + outbox (PostgreSQL)
   │
   ├── polling mode: OutboxPublisher (SELECT … FOR UPDATE SKIP LOCKED) ─┐
   └── cdc mode:     Debezium EventRouter reads the WAL ────────────────┤
                                                                         ▼
                                                              Kafka topic order.events
                                                                         ▼
                                              OrderEventsListener → InventoryService
                                              (processed_events inbox + side effect, one tx)
```

## Requirements
Java 17+, Maven 3.9+, Docker.

## Run (polling publisher)
```bash
docker compose up -d
mvn spring-boot:run

curl -X POST localhost:8080/api/orders -H 'Content-Type: application/json' \
     -d '{"customerId":"cust-1","amount":249.50}'

curl localhost:8080/api/inventory/reservations
```
Check the outbox: `docker compose exec postgres psql -U postgres orders_db -c "select id,event_type,status,retry_count from outbox"`

### Try the failure scenarios
* **Kafka down:** `docker compose stop kafka`, create orders (they still succeed, rows stay `NEW`),
  `docker compose start kafka` → rows are published and become `SENT`.
* **Duplicate delivery:** run the test `duplicateDeliveryOfTheSameEventIdIsIgnored`.

## Run with Debezium (CDC)
```bash
docker compose --profile cdc up -d
curl -X POST -H 'Content-Type: application/json' \
     --data @debezium/outbox-connector.json localhost:8083/connectors
mvn spring-boot:run -Dspring-boot.run.arguments=--outbox.mode=cdc
```
In `cdc` mode the app does not publish anything. It inserts the outbox row and deletes it in the same
transaction (the WAL already contains the insert), and Debezium's EventRouter publishes to `order.events`
with the row id in the `id` header, which the consumer uses for de-duplication.

## Tests
`mvn test` (needs Docker; starts PostgreSQL and Kafka via Testcontainers).

## Key design points
| Concern | Where |
|---|---|
| Atomic write of business data + event | `OrderService#createOrder`, `OutboxService` (`Propagation.MANDATORY`) |
| Stable event id (generated once) | `OutboxService#append` |
| Safe concurrent publishers | `FOR UPDATE SKIP LOCKED` in `OutboxRepository` |
| Per-order ordering | Kafka key = aggregate id; publisher stops the batch on first failure |
| Retry / failure parking | `retry_count`, `FAILED` status after `outbox.max-retries` |
| Clean-up | `OutboxCleanupJob` (hourly, `outbox.retention-hours`) |
| Idempotent consumer | `ProcessedEventRepository` + `InventoryService` (one transaction) |
| Poison messages | `DefaultErrorHandler` + dead-letter topic `order.events.DLT` |

## Trade-offs to be aware of
* The polling publisher holds a DB transaction open while waiting for the Kafka ack. Fine for small batches;
  use CDC for high throughput.
* `ORDER BY seq` follows insert order, not commit order, so strict global ordering is not guaranteed across
  concurrent transactions. Per-aggregate ordering is what the Kafka key gives you.
* Everything lives in one database here for the demo. In a real system the consumer owns its own database
  (with its own `processed_events` table).
