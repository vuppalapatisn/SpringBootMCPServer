package com.example.outbox;

import com.example.outbox.inventory.InventoryService;
import com.example.outbox.order.CreateOrderRequest;
import com.example.outbox.order.Order;
import com.example.outbox.order.OrderService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.testcontainers.service.connection.ServiceConnection;
import org.springframework.jdbc.core.JdbcTemplate;
import org.testcontainers.containers.KafkaContainer;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;
import org.testcontainers.utility.DockerImageName;

import java.math.BigDecimal;
import java.time.Duration;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.awaitility.Awaitility.await;

/** Needs Docker (Testcontainers starts real PostgreSQL + Kafka). */
@SpringBootTest(properties = "outbox.poll-interval-ms=200")
@Testcontainers
class OutboxFlowTest {

    @Container
    @ServiceConnection
    static PostgreSQLContainer<?> postgres = new PostgreSQLContainer<>("postgres:16-alpine");

    @Container
    @ServiceConnection
    static KafkaContainer kafka = new KafkaContainer(DockerImageName.parse("confluentinc/cp-kafka:7.6.1"));

    @Autowired OrderService orderService;
    @Autowired InventoryService inventoryService;
    @Autowired JdbcTemplate jdbc;

    @Test
    void orderCreatedEventIsPublishedFromOutboxAndConsumedOnce() {
        Order order = orderService.createOrder(new CreateOrderRequest("cust-1", new BigDecimal("99.90")));

        // event row was written together with the order
        Integer outboxRows = jdbc.queryForObject(
                "SELECT count(*) FROM outbox WHERE aggregate_id = ?", Integer.class, order.getId().toString());
        assertThat(outboxRows).isEqualTo(1);

        // publisher -> Kafka -> consumer -> reservation
        await().atMost(Duration.ofSeconds(30)).untilAsserted(() -> {
            Integer reservations = jdbc.queryForObject(
                    "SELECT count(*) FROM inventory_reservations WHERE order_no = ?", Integer.class, order.getOrderNo());
            assertThat(reservations).isEqualTo(1);
        });

        // and the outbox row is marked as SENT
        await().atMost(Duration.ofSeconds(10)).untilAsserted(() -> {
            String status = jdbc.queryForObject(
                    "SELECT status FROM outbox WHERE aggregate_id = ?", String.class, order.getId().toString());
            assertThat(status).isEqualTo("SENT");
        });
    }

    @Test
    void duplicateDeliveryOfTheSameEventIdIsIgnored() {
        UUID eventId = UUID.randomUUID();
        UUID orderId = UUID.randomUUID();
        String payload = """
                {"orderId":"%s","orderNo":"ORD-DUP-1","customerId":"c","amount":10.00,
                 "status":"CREATED","occurredAt":"2026-01-01T00:00:00Z"}
                """.formatted(orderId);

        inventoryService.handle(eventId, "OrderCreated", payload);
        inventoryService.handle(eventId, "OrderCreated", payload);   // simulated replay after a crash

        assertThat(jdbc.queryForObject(
                "SELECT count(*) FROM processed_events WHERE event_id = ?", Integer.class, eventId)).isEqualTo(1);
        assertThat(jdbc.queryForObject(
                "SELECT count(*) FROM inventory_reservations WHERE order_no = 'ORD-DUP-1'", Integer.class)).isEqualTo(1);
    }
}
