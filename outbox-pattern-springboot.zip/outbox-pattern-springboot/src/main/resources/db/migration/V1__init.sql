-- Business table
CREATE TABLE orders (
    id          UUID PRIMARY KEY,
    order_no    VARCHAR(40)    NOT NULL UNIQUE,
    customer_id VARCHAR(100)   NOT NULL,
    amount      NUMERIC(12, 2) NOT NULL,
    status      VARCHAR(30)    NOT NULL,
    created_at  TIMESTAMPTZ    NOT NULL
);

-- Outbox: written in the SAME transaction as the business data
CREATE TABLE outbox (
    id             UUID PRIMARY KEY,            -- stable event id, used for consumer de-duplication
    seq            BIGSERIAL    NOT NULL,       -- ordering for the polling publisher
    aggregate_type VARCHAR(100) NOT NULL,       -- "order" -> topic "order.events"
    aggregate_id   VARCHAR(100) NOT NULL,       -- Kafka message key -> per-aggregate ordering
    event_type     VARCHAR(100) NOT NULL,
    payload        JSONB        NOT NULL,
    status         VARCHAR(20)  NOT NULL DEFAULT 'NEW',   -- NEW | SENT | FAILED
    retry_count    INT          NOT NULL DEFAULT 0,
    last_error     TEXT,
    created_at     TIMESTAMPTZ  NOT NULL DEFAULT now(),
    published_at   TIMESTAMPTZ
);
CREATE INDEX idx_outbox_pending ON outbox (seq) WHERE status = 'NEW';
CREATE INDEX idx_outbox_sent ON outbox (published_at) WHERE status = 'SENT';

-- Consumer side ("inbox"): remembers which events were already applied
-- (in a real system this lives in the consumer service's own database)
CREATE TABLE processed_events (
    event_id     UUID         NOT NULL,
    consumer     VARCHAR(100) NOT NULL,
    processed_at TIMESTAMPTZ  NOT NULL DEFAULT now(),
    PRIMARY KEY (event_id, consumer)
);

-- Example side effect of the consumer
CREATE TABLE inventory_reservations (
    order_no    VARCHAR(40) PRIMARY KEY,
    order_id    UUID        NOT NULL,
    reserved_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
