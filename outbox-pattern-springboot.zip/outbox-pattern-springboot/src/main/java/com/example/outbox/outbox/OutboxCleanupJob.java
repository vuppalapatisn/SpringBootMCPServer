package com.example.outbox.outbox;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/** Keeps the outbox table small by deleting rows that were published long ago. */
@Component
@ConditionalOnProperty(name = "outbox.mode", havingValue = "polling", matchIfMissing = true)
public class OutboxCleanupJob {

    private static final Logger log = LoggerFactory.getLogger(OutboxCleanupJob.class);

    private final OutboxRepository repository;
    private final int retentionHours;

    public OutboxCleanupJob(OutboxRepository repository,
                            @Value("${outbox.retention-hours:24}") int retentionHours) {
        this.repository = repository;
        this.retentionHours = retentionHours;
    }

    @Scheduled(cron = "0 0 * * * *")
    public void cleanup() {
        int deleted = repository.deleteSentOlderThanHours(retentionHours);
        if (deleted > 0) {
            log.info("Outbox cleanup removed {} published rows", deleted);
        }
    }
}
