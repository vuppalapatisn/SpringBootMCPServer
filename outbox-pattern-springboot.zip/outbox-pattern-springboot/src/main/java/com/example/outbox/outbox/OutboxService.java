package com.example.outbox.outbox;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;

@Service
public class OutboxService {

    private final OutboxRepository repository;
    private final ObjectMapper objectMapper;
    private final boolean cdcMode;

    public OutboxService(OutboxRepository repository,
                         ObjectMapper objectMapper,
                         @Value("${outbox.mode:polling}") String mode) {
        this.repository = repository;
        this.objectMapper = objectMapper;
        this.cdcMode = "cdc".equalsIgnoreCase(mode);
    }

    /**
     * MANDATORY: this must be called inside the caller's business transaction.
     * If someone calls it without one, it fails fast instead of silently re-creating the dual-write problem.
     */
    @Transactional(propagation = Propagation.MANDATORY)
    public UUID append(String aggregateType, String aggregateId, String eventType, Object payload) {
        UUID eventId = UUID.randomUUID();   // generated ONCE -> stays identical on every re-publish
        String json;
        try {
            json = objectMapper.writeValueAsString(payload);
        } catch (JsonProcessingException e) {
            throw new IllegalStateException("Cannot serialize outbox payload", e);
        }

        repository.insert(new OutboxEvent(eventId, aggregateType, aggregateId, eventType, json));

        if (cdcMode) {
            // Debezium reads the INSERT from the WAL, so the row itself is not needed any more.
            // Insert + delete in the same transaction keeps the table tiny.
            repository.delete(eventId);
        }
        return eventId;
    }
}
