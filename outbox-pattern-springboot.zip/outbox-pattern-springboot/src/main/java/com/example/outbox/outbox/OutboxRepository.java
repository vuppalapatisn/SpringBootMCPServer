package com.example.outbox.outbox;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public class OutboxRepository {

    private final JdbcTemplate jdbc;

    public OutboxRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public void insert(OutboxEvent e) {
        jdbc.update("""
                INSERT INTO outbox (id, aggregate_type, aggregate_id, event_type, payload)
                VALUES (?, ?, ?, ?, ?::jsonb)
                """, e.id(), e.aggregateType(), e.aggregateId(), e.eventType(), e.payload());
    }

    public void delete(UUID id) {
        jdbc.update("DELETE FROM outbox WHERE id = ?", id);
    }

    /**
     * Locks a batch of pending rows. FOR UPDATE SKIP LOCKED lets several app instances
     * run the publisher at the same time without picking the same rows.
     */
    public List<OutboxEvent> lockPendingBatch(int batchSize) {
        return jdbc.query("""
                SELECT id, aggregate_type, aggregate_id, event_type, payload::text AS payload
                FROM outbox
                WHERE status = 'NEW'
                ORDER BY seq
                LIMIT ?
                FOR UPDATE SKIP LOCKED
                """,
                (rs, i) -> new OutboxEvent(
                        rs.getObject("id", UUID.class),
                        rs.getString("aggregate_type"),
                        rs.getString("aggregate_id"),
                        rs.getString("event_type"),
                        rs.getString("payload")),
                batchSize);
    }

    public void markSent(UUID id) {
        jdbc.update("UPDATE outbox SET status = 'SENT', published_at = now() WHERE id = ?", id);
    }

    /** Records a failed attempt; after maxRetries the row is parked as FAILED for manual attention. */
    public void recordFailure(UUID id, String error, int maxRetries) {
        jdbc.update("""
                UPDATE outbox
                SET retry_count = retry_count + 1,
                    last_error  = ?,
                    status      = CASE WHEN retry_count + 1 >= ? THEN 'FAILED' ELSE status END
                WHERE id = ?
                """, error, maxRetries, id);
    }

    /** Clean-up strategy: remove rows that were published long ago. */
    public int deleteSentOlderThanHours(int hours) {
        return jdbc.update("""
                DELETE FROM outbox
                WHERE status = 'SENT' AND published_at < now() - make_interval(hours => ?)
                """, hours);
    }
}
