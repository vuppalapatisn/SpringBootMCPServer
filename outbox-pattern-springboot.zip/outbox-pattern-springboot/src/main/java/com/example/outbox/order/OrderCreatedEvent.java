package com.example.outbox.order;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

/** Event payload stored in the outbox and published to Kafka. */
public record OrderCreatedEvent(
        UUID orderId,
        String orderNo,
        String customerId,
        BigDecimal amount,
        String status,
        Instant occurredAt) {
}
