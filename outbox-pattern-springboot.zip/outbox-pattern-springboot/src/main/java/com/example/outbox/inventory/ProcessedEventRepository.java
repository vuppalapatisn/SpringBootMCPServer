package com.example.outbox.inventory;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.UUID;

/** The "inbox": remembers which event ids a consumer has already applied. */
@Repository
public class ProcessedEventRepository {

    private final JdbcTemplate jdbc;

    public ProcessedEventRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    /**
     * @return true if this is the first time we see the event, false if it is a duplicate.
     * The primary key (event_id, consumer) makes the check race-safe across consumer instances.
     */
    public boolean markProcessed(UUID eventId, String consumer) {
        return jdbc.update("""
                INSERT INTO processed_events (event_id, consumer)
                VALUES (?, ?)
                ON CONFLICT (event_id, consumer) DO NOTHING
                """, eventId, consumer) == 1;
    }
}
