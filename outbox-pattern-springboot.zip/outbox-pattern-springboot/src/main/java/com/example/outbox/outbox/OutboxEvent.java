package com.example.outbox.outbox;

import java.util.UUID;

public record OutboxEvent(
        UUID id,
        String aggregateType,
        String aggregateId,
        String eventType,
        String payload) {

    /** "order" -> "order.events" (same convention as the Debezium EventRouter config). */
    public String topic() {
        return aggregateType + ".events";
    }
}
