package com.example.outbox.inventory;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.header.Header;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.util.UUID;

/**
 * Step 6: consumer. Offsets are committed by the container only AFTER handle() returns,
 * so this is at-least-once; InventoryService makes the effect exactly-once.
 */
@Component
public class OrderEventsListener {

    private static final Logger log = LoggerFactory.getLogger(OrderEventsListener.class);

    private final InventoryService inventoryService;

    public OrderEventsListener(InventoryService inventoryService) {
        this.inventoryService = inventoryService;
    }

    @KafkaListener(topics = "order.events", groupId = "inventory-service")
    public void onMessage(ConsumerRecord<String, String> record) {
        // Polling publisher sends "event_id"/"event_type"; Debezium EventRouter sends "id"/"eventType"
        String id = header(record, "event_id");
        if (id == null) {
            id = header(record, "id");
        }
        if (id == null) {
            // No stable id -> cannot de-duplicate -> let the error handler retry / dead-letter it
            throw new IllegalStateException("Missing event id header on " + record.topic()
                    + "-" + record.partition() + "@" + record.offset());
        }

        String type = header(record, "event_type");
        if (type == null) {
            type = header(record, "eventType");
        }

        log.info("Received {} (key={}, partition={}, offset={})", type, record.key(), record.partition(), record.offset());
        inventoryService.handle(UUID.fromString(id), type, record.value());
    }

    private static String header(ConsumerRecord<?, ?> record, String name) {
        Header h = record.headers().lastHeader(name);
        return h == null ? null : new String(h.value(), StandardCharsets.UTF_8);
    }
}
