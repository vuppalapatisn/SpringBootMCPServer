package com.example.outbox.order;

import com.example.outbox.outbox.OutboxService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.UUID;

@Service
public class OrderService {

    private final OrderRepository orderRepository;
    private final OutboxService outboxService;

    public OrderService(OrderRepository orderRepository, OutboxService outboxService) {
        this.orderRepository = orderRepository;
        this.outboxService = outboxService;
    }

    /**
     * Steps 1-4 of the pattern: ONE database transaction that
     *   (2) saves the business data and
     *   (3) saves the event in the outbox table;
     *   (4) both are committed atomically - or neither is.
     * Nothing here talks to Kafka.
     */
    @Transactional
    public Order createOrder(CreateOrderRequest request) {
        Order order = orderRepository.save(
                new Order(generateOrderNo(), request.customerId(), request.amount()));

        outboxService.append(
                "order",                              // aggregate type -> topic "order.events"
                order.getId().toString(),             // aggregate id   -> Kafka key (ordering)
                "OrderCreated",
                new OrderCreatedEvent(order.getId(), order.getOrderNo(), order.getCustomerId(),
                        order.getAmount(), order.getStatus(), Instant.now()));

        return order;
    }

    private static String generateOrderNo() {
        return "ORD-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
    }
}
