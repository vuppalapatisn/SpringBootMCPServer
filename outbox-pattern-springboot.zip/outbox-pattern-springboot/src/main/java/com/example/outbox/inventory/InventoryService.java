package com.example.outbox.inventory;

import com.example.outbox.order.OrderCreatedEvent;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;

/**
 * Idempotent consumer logic.
 *
 * The inbox insert and the business side effect run in ONE local transaction:
 *   - duplicate event  -> inbox insert is a no-op -> we skip the side effect
 *   - failure midway   -> both roll back          -> the event is retried safely
 * This is the consumer-side mirror image of the outbox on the producer side.
 */
@Service
public class InventoryService {

    private static final Logger log = LoggerFactory.getLogger(InventoryService.class);
    static final String CONSUMER_NAME = "inventory-service";

    private final ProcessedEventRepository processedEvents;
    private final JdbcTemplate jdbc;
    private final ObjectMapper objectMapper;

    public InventoryService(ProcessedEventRepository processedEvents, JdbcTemplate jdbc, ObjectMapper objectMapper) {
        this.processedEvents = processedEvents;
        this.jdbc = jdbc;
        this.objectMapper = objectMapper;
    }

    @Transactional
    public void handle(UUID eventId, String eventType, String payload) {
        if (!processedEvents.markProcessed(eventId, CONSUMER_NAME)) {
            log.info("Duplicate event {} ignored", eventId);
            return;
        }

        if ("OrderCreated".equals(eventType)) {
            OrderCreatedEvent event = parse(payload);
            reserveStock(event);
        } else {
            log.debug("Ignoring unknown event type {}", eventType);
        }
    }

    private void reserveStock(OrderCreatedEvent event) {
        // Naturally idempotent as well: ON CONFLICT DO NOTHING
        jdbc.update("""
                INSERT INTO inventory_reservations (order_no, order_id)
                VALUES (?, ?)
                ON CONFLICT (order_no) DO NOTHING
                """, event.orderNo(), event.orderId());
        log.info("Reserved inventory for order {}", event.orderNo());
    }

    private OrderCreatedEvent parse(String payload) {
        try {
            return objectMapper.readValue(payload, OrderCreatedEvent.class);
        } catch (JsonProcessingException e) {
            throw new IllegalArgumentException("Invalid OrderCreated payload", e);
        }
    }
}
