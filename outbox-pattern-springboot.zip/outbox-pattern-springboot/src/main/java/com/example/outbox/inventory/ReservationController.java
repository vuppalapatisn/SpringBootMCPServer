package com.example.outbox.inventory;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

/** Demo endpoint to verify that events were consumed. */
@RestController
@RequestMapping("/api/inventory")
public class ReservationController {

    private final JdbcTemplate jdbc;

    public ReservationController(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    @GetMapping("/reservations")
    public List<Map<String, Object>> reservations() {
        return jdbc.queryForList("SELECT order_no, order_id, reserved_at FROM inventory_reservations ORDER BY reserved_at DESC");
    }
}
