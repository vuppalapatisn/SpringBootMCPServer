package com.example.outbox.outbox;

import org.apache.kafka.clients.producer.ProducerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Steps 5-6: background publisher (the alternative to Debezium).
 *
 * Delivery guarantee: AT-LEAST-ONCE. If the app crashes after Kafka acknowledged the message
 * but before the row is marked SENT (i.e. before this transaction commits), the row is picked up
 * again and re-published. Consumers must therefore be idempotent (see InventoryService).
 */
@Component
@ConditionalOnProperty(name = "outbox.mode", havingValue = "polling", matchIfMissing = true)
public class OutboxPublisher {

    private static final Logger log = LoggerFactory.getLogger(OutboxPublisher.class);

    private final OutboxRepository repository;
    private final KafkaTemplate<String, String> kafkaTemplate;
    private final int batchSize;
    private final long sendTimeoutSeconds;
    private final int maxRetries;

    public OutboxPublisher(OutboxRepository repository,
                           KafkaTemplate<String, String> kafkaTemplate,
                           @Value("${outbox.batch-size:50}") int batchSize,
                           @Value("${outbox.send-timeout-seconds:5}") long sendTimeoutSeconds,
                           @Value("${outbox.max-retries:10}") int maxRetries) {
        this.repository = repository;
        this.kafkaTemplate = kafkaTemplate;
        this.batchSize = batchSize;
        this.sendTimeoutSeconds = sendTimeoutSeconds;
        this.maxRetries = maxRetries;
    }

    @Scheduled(fixedDelayString = "${outbox.poll-interval-ms:1000}")
    @Transactional
    public void publishPending() {
        List<OutboxEvent> batch = repository.lockPendingBatch(batchSize);
        if (batch.isEmpty()) {
            return;
        }

        for (OutboxEvent event : batch) {
            try {
                ProducerRecord<String, String> record =
                        new ProducerRecord<>(event.topic(), event.aggregateId(), event.payload());
                record.headers().add("event_id", event.id().toString().getBytes(StandardCharsets.UTF_8));
                record.headers().add("event_type", event.eventType().getBytes(StandardCharsets.UTF_8));

                // Block until the broker acknowledges (acks=all) - only then mark as SENT
                kafkaTemplate.send(record).get(sendTimeoutSeconds, TimeUnit.SECONDS);
                repository.markSent(event.id());
                log.info("Published outbox event {} ({}) to {}", event.id(), event.eventType(), event.topic());

            } catch (InterruptedException ie) {
                Thread.currentThread().interrupt();
                return;
            } catch (Exception ex) {
                // Kafka down / timeout: the row stays NEW and is retried on the next poll.
                // Stop the batch so events are never published out of order.
                log.warn("Failed to publish outbox event {}: {}", event.id(), ex.toString());
                repository.recordFailure(event.id(), String.valueOf(ex.getMessage()), maxRetries);
                return;
            }
        }
    }
}
